# Implementation Specification

## 1. Scope

Build an Android client and broker-independent backend for NIFTY/BANK NIFTY intraday CE/PE options. The first milestone is research + backtesting + paper trading only. Live order execution is intentionally absent.

## 2. Functional requirements

### Strategy
- Aggregate/consume 5-minute OHLC candles.
- Calculate EMA(12), EMA(26), RSI(14).
- CE candidate when fast EMA crosses from at/below to above slow EMA and RSI > 55.
- PE candidate when fast EMA crosses from at/above to below slow EMA and RSI < 45.
- Signals are evaluated only on completed candles.
- Do not enter when candles are stale, missing, duplicated, out of sequence, or outside configured session.
- Underlying signal is a candidate only; a contract-selection layer must validate expiry, strike, lot size, tradability, liquidity, spread and market status.

### Risk
- Default risk budget: ₹250 per trade.
- Default daily loss lockout: ₹1,000.
- Default maximum entries: 5/day.
- Default long-option premium stop: 20% below average entry price.
- Quantity = floor(risk budget / (entry premium × stop percentage × lot size)), bounded by valid lot size and available margin. If quantity is zero, reject the trade. Never round quantity up.
- Count a trade when an entry is accepted/filled according to the defined policy; avoid counting duplicate retries twice.
- Daily loss includes realized P&L plus conservative mark-to-market open P&L and estimated charges. Reset only at the configured exchange trading-day boundary.
- On daily limit hit: block new entries, cancel eligible pending entry orders, alert operator, and manage open risk using the configured protective policy.
- Include max exposure, max open positions, max order rate, stale-feed cutoff and repeated-error circuit breakers before any live deployment.

### Paper broker
- Simulate submissions, fills, rejections, fees and stop exits.
- Clearly label all orders and P&L as SIMULATED.
- Paper broker must not have access to credentials or a live broker client.

### Backtesting
- Use timestamped historical data with no look-ahead.
- Generate signals only after candle close.
- Model option contract history, bid/ask, slippage, brokerage, taxes/charges, lot sizes and expiry/strike selection.
- Report total trades, win rate, net P&L after costs, maximum drawdown, profit factor, average win/loss, exposure and rejected entries.
- Separate in-sample/out-of-sample periods and include walk-forward testing.
- If historical option bid/ask or contract data is missing, report that limitation rather than fabricating fills.

### Order lifecycle / reconciliation (interface only in starter)
- Normalize broker order states into `NEW`, `ACKNOWLEDGED`, `OPEN`, `PARTIALLY_FILLED`, `FILLED`, `CANCEL_PENDING`, `CANCELLED`, `REJECTED`, `UNKNOWN`.
- Treat timeouts as `UNKNOWN`, not as failed submissions. Query broker state before retrying to prevent duplicate orders.
- Reconcile broker orders, trades, positions and local ledger at startup and periodically.
- Any mismatch blocks new entries and raises an alert until resolved.
- Use idempotency keys where supported; persist request/response IDs and timestamps.

### Emergency shutdown
- Kill switch is latched and persistent.
- Blocks all new entries immediately.
- Requests cancellation of pending entry orders.
- Open positions are handled by an explicit policy: preserve protective exits or submit a controlled exit according to broker capabilities and exchange rules. Do not assume cancelling all orders is safe.
- Require an authenticated operator action and audit event to reset.
- Include backend and Android controls; Android control is not the sole safety mechanism.

## 3. Architecture

Android app -> authenticated API -> strategy/risk services -> paper execution adapter -> append-only audit ledger.
A future broker adapter must be a separate module and must remain disabled unless explicitly configured and reviewed.

## 4. Security

- TLS in transit; authentication and authorization on all non-health endpoints.
- Never embed broker API secrets in APK.
- Store server secrets in a secret manager; rotate and revoke credentials.
- Encrypt sensitive data at rest, minimize logs, redact tokens and personal data.
- Apply rate limits, request validation, replay protection and dependency updates.
- Record who changed strategy/risk settings and the before/after values.
- Android app must clearly display PAPER / LIVE mode; default and fallback are PAPER.

## 5. Operational safeguards

- Clock synchronization and exchange calendar.
- Market-data freshness checks and feed-health dashboard.
- Persistent state, crash recovery and startup reconciliation.
- Monitoring/alerts for disconnects, rejected orders, slippage, loss limits and risk-engine failures.
- Fail closed: if risk service, market data, clock, contract master or reconciliation is unhealthy, do not open new positions.
- Tested backup/recovery and incident response runbook.

## 6. Acceptance criteria

1. Unit tests cover EMA crossover, RSI thresholds, no-signal cases, invalid candle sequences and insufficient history.
2. Risk engine rejects trade when risk budget produces zero lots, daily loss limit is hit, max trades reached, or kill switch is active.
3. Duplicate signal/order IDs cannot create duplicate paper positions.
4. Kill switch prevents new entries and persists through process restart in production storage.
5. Backtest never uses a candle before its close timestamp.
6. Paper/live separation is enforced by build configuration and server-side authorization; starter project has no live execution implementation.
7. Logs include UTC timestamp, trading date, signal ID, decision, reason, simulated order ID and risk snapshot.
8. Broker and compliance reviews are completed before a live adapter is developed or enabled.
