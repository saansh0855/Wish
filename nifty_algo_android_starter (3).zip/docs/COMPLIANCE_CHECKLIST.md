# Pre-Live Compliance and Broker Checklist

This checklist is not legal advice. Verify current requirements directly with the selected SEBI-registered broker, exchange and qualified compliance counsel.

- [ ] Confirm current SEBI retail algorithmic-trading framework and applicable exchange circulars.
- [ ] Confirm broker permits the proposed API use, strategy automation, order types, rate limits and authentication method.
- [ ] Confirm any required algo registration, tagging, approvals, static-IP or hosting conditions that apply to this client and broker.
- [ ] Confirm permitted order placement, modification, cancellation and stop-loss order types.
- [ ] Confirm current NIFTY/BANK NIFTY derivatives contract specifications, lot sizes, expiries, strike intervals and market timings from official sources.
- [ ] Confirm market-data licensing and historical-data rights.
- [ ] Implement exchange holidays, special sessions, expiry-day rules and product restrictions.
- [ ] Perform security review, penetration testing, key rotation and incident-response drills.
- [ ] Validate order reconciliation and duplicate-prevention under timeout/network-failure scenarios.
- [ ] Test kill switch with pending entries, open positions, disconnects and backend restarts.
- [ ] Obtain explicit operator approval and use broker-provided test/sandbox facilities where available.
- [ ] Start with paper trading; do not enable live orders until all required reviews and approvals are complete.

No live broker adapter is included in this starter project.
