from fastapi import FastAPI, HTTPException
from .config import CONFIG
from .models import SignalRequest, SignalResponse
from .strategy import evaluate_signal
from .paper import STATE, BROKER
from .audit import audit

app = FastAPI(title="NIFTY Algo Starter API", version="0.1.0",
              description="Paper/research scaffold. No live trading endpoints.")

@app.get("/health")
def health():
    return {"status": "ok", "mode": "PAPER", "live_trading_available": False}

@app.get("/config")
def config():
    return CONFIG.model_dump()

@app.post("/signal", response_model=SignalResponse)
def signal(req: SignalRequest):
    result = evaluate_signal(req.candles, req.symbol.upper())
    audit("SIGNAL_EVALUATED", {"symbol": req.symbol.upper(), **result})
    return SignalResponse(symbol=req.symbol.upper(), mode="PAPER", **result)

@app.get("/paper/status")
def paper_status():
    return {"mode": "PAPER", "kill_switch": STATE.kill_switch,
            "orders": STATE.orders, "positions": STATE.positions}

@app.post("/paper/kill-switch")
def kill_switch():
    return BROKER.emergency_stop()

@app.post("/paper/reset-kill-switch")
def reset_kill_switch():
    # Development-only endpoint; protect with authentication before any shared deployment.
    STATE.kill_switch = False
    audit("PAPER_KILL_SWITCH_RESET", {"mode": "PAPER"})
    return {"kill_switch": False, "mode": "PAPER", "warning": "Development endpoint; add authentication before deployment."}
