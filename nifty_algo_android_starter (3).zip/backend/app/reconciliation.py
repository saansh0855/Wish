from enum import Enum

class NormalizedOrderStatus(str, Enum):
    NEW = "NEW"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    OPEN = "OPEN"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCEL_PENDING = "CANCEL_PENDING"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    UNKNOWN = "UNKNOWN"

def should_retry_submission(status: NormalizedOrderStatus) -> bool:
    # Safe default: never retry an ambiguous submission until remote state is queried.
    return status in {NormalizedOrderStatus.REJECTED, NormalizedOrderStatus.CANCELLED}
