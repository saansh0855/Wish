from dataclasses import dataclass

@dataclass
class RiskState:
    trades_today: int = 0
    realized_pnl: float = 0.0
    open_pnl: float = 0.0
    kill_switch: bool = False

@dataclass
class RiskDecision:
    allowed: bool
    reason: str
    quantity_lots: int = 0
    stop_price: float | None = None

def quantity_for_risk(entry_premium: float, lot_size: int, risk_budget: float = 250.0,
                      stop_pct: float = 0.20) -> int:
    if entry_premium <= 0 or lot_size <= 0 or risk_budget <= 0 or not 0 < stop_pct < 1:
        return 0
    risk_per_lot = entry_premium * stop_pct * lot_size
    if risk_per_lot <= 0:
        return 0
    return int(risk_budget // risk_per_lot)

def approve_entry(state: RiskState, entry_premium: float, lot_size: int,
                  risk_budget: float = 250.0, daily_loss_limit: float = 1000.0,
                  max_trades: int = 5, stop_pct: float = 0.20) -> RiskDecision:
    if state.kill_switch:
        return RiskDecision(False, "Kill switch active")
    if state.realized_pnl + min(state.open_pnl, 0) <= -abs(daily_loss_limit):
        return RiskDecision(False, "Daily loss limit reached")
    if state.trades_today >= max_trades:
        return RiskDecision(False, "Maximum trades per day reached")
    lots = quantity_for_risk(entry_premium, lot_size, risk_budget, stop_pct)
    if lots < 1:
        return RiskDecision(False, "Risk budget insufficient for one lot")
    return RiskDecision(True, "Approved for paper entry", lots, entry_premium * (1 - stop_pct))
