from datetime import datetime, timezone
from pathlib import Path
import json

AUDIT_PATH = Path("audit.jsonl")

def audit(event: str, details: dict) -> None:
    record = {"timestamp": datetime.now(timezone.utc).isoformat(), "event": event, "details": details}
    with AUDIT_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, default=str, sort_keys=True) + "\n")
