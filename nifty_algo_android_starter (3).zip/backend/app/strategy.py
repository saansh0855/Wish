from .models import Candle
from .config import CONFIG

def ema(values: list[float], period: int) -> list[float | None]:
    if period <= 0:
        raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    if len(values) < period:
        return out
    seed = sum(values[:period]) / period
    out[period - 1] = seed
    alpha = 2 / (period + 1)
    prev = seed
    for i in range(period, len(values)):
        prev = values[i] * alpha + prev * (1 - alpha)
        out[i] = prev
    return out

def rsi(values: list[float], period: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(values)
    if len(values) <= period:
        return out
    gains, losses = [], []
    for i in range(1, len(values)):
        delta = values[i] - values[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    def value(g, l):
        if l == 0:
            return 100.0 if g > 0 else 50.0
        rs = g / l
        return 100 - (100 / (1 + rs))
    out[period] = value(avg_gain, avg_loss)
    for i in range(period + 1, len(values)):
        gain, loss = gains[i - 1], losses[i - 1]
        avg_gain = ((avg_gain * (period - 1)) + gain) / period
        avg_loss = ((avg_loss * (period - 1)) + loss) / period
        out[i] = value(avg_gain, avg_loss)
    return out

def evaluate_signal(candles: list[Candle], symbol: str) -> dict:
    if symbol not in CONFIG.allowed_underlyings:
        return {"signal": "NONE", "reason": "Unsupported underlying"}
    if len(candles) < max(CONFIG.slow_ema + 2, CONFIG.rsi_period + 2):
        return {"signal": "NONE", "reason": "Insufficient candle history"}
    times = [c.timestamp for c in candles]
    if any(times[i] >= times[i + 1] for i in range(len(times) - 1)):
        return {"signal": "NONE", "reason": "Candle timestamps must be strictly increasing"}
    closes = [c.close for c in candles]
    fast = ema(closes, CONFIG.fast_ema)
    slow = ema(closes, CONFIG.slow_ema)
    rsis = rsi(closes, CONFIG.rsi_period)
    i = len(closes) - 1
    if fast[i] is None or slow[i] is None or fast[i-1] is None or slow[i-1] is None or rsis[i] is None:
        return {"signal": "NONE", "reason": "Indicators not initialized"}
    # Signal only on the latest completed candle supplied by caller.
    if fast[i-1] <= slow[i-1] and fast[i] > slow[i] and rsis[i] > CONFIG.ce_rsi_min:
        signal, reason = "CE_CANDIDATE", "Bullish EMA crossover with RSI confirmation"
    elif fast[i-1] >= slow[i-1] and fast[i] < slow[i] and rsis[i] < CONFIG.pe_rsi_max:
        signal, reason = "PE_CANDIDATE", "Bearish EMA crossover with RSI confirmation"
    else:
        signal, reason = "NONE", "No confirmed crossover + RSI signal"
    return {"signal": signal, "reason": reason, "ema_fast": fast[i], "ema_slow": slow[i], "rsi": rsis[i]}
