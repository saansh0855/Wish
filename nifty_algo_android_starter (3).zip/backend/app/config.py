from pydantic import BaseModel, Field

class TradingConfig(BaseModel):
    mode: str = "PAPER"
    fast_ema: int = Field(default=12, ge=2)
    slow_ema: int = Field(default=26, ge=3)
    rsi_period: int = Field(default=14, ge=2)
    ce_rsi_min: float = 55.0
    pe_rsi_max: float = 45.0
    timeframe_minutes: int = 5
    risk_per_trade_inr: float = Field(default=250.0, gt=0)
    daily_loss_limit_inr: float = Field(default=1000.0, gt=0)
    max_trades_per_day: int = Field(default=5, ge=1)
    premium_stop_pct: float = Field(default=0.20, gt=0, lt=1)
    allowed_underlyings: list[str] = ["NIFTY", "BANKNIFTY"]

CONFIG = TradingConfig()
