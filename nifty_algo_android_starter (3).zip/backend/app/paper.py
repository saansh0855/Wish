from dataclasses import dataclass, field
from .audit import audit

@dataclass
class PaperState:
    kill_switch: bool = False
    orders: list[dict] = field(default_factory=list)
    positions: list[dict] = field(default_factory=list)

STATE = PaperState()

class PaperBroker:
    """Simulation-only adapter. Deliberately has no live broker credentials or route."""
    def submit_entry(self, symbol: str, side: str, qty_lots: int, entry_premium: float, stop_price: float) -> dict:
        if STATE.kill_switch:
            return {"status": "REJECTED", "reason": "Kill switch active"}
        order = {
            "order_id": f"PAPER-{len(STATE.orders)+1:06d}",
            "symbol": symbol, "side": side, "qty_lots": qty_lots,
            "entry_premium": entry_premium, "stop_price": stop_price,
            "status": "SIMULATED_FILLED", "mode": "PAPER"
        }
        STATE.orders.append(order)
        STATE.positions.append(order.copy())
        audit("PAPER_ORDER_SIMULATED", order)
        return order

    def emergency_stop(self) -> dict:
        STATE.kill_switch = True
        audit("PAPER_KILL_SWITCH_ACTIVATED", {"open_positions": len(STATE.positions)})
        # Starter behavior: mark positions as needing operator review; do not pretend fills.
        return {"kill_switch": True, "new_entries_blocked": True,
                "positions_requiring_review": len(STATE.positions), "mode": "PAPER"}

BROKER = PaperBroker()
