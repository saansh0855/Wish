from datetime import datetime
from pydantic import BaseModel, Field

class Candle(BaseModel):
    timestamp: datetime
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(default=0, ge=0)

class SignalRequest(BaseModel):
    symbol: str
    candles: list[Candle]

class SignalResponse(BaseModel):
    symbol: str
    signal: str
    reason: str
    ema_fast: float | None = None
    ema_slow: float | None = None
    rsi: float | None = None
    mode: str = "PAPER"
