from datetime import datetime, timedelta, timezone
from app.models import Candle
from app.strategy import ema, rsi, evaluate_signal

def test_ema_length_and_seed():
    values = [1,2,3,4,5]
    out = ema(values, 3)
    assert out[:2] == [None, None]
    assert out[2] == 2

def test_rsi_constant_series():
    vals = [100.0] * 20
    out = rsi(vals, 14)
    assert out[14] == 50.0

def test_rejects_unsorted_candles():
    now = datetime.now(timezone.utc)
    candles = [
        Candle(timestamp=now, open=100, high=101, low=99, close=100),
        Candle(timestamp=now-timedelta(minutes=5), open=100, high=101, low=99, close=100),
        *[Candle(timestamp=now+timedelta(minutes=5*i), open=100+i, high=101+i, low=99+i, close=100+i) for i in range(1, 35)]
    ]
    assert evaluate_signal(candles, "NIFTY")["signal"] == "NONE"
