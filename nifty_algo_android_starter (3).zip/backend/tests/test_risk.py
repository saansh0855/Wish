from app.risk import RiskState, approve_entry, quantity_for_risk

def test_quantity_risk_budget():
    # Premium ₹100, 20% stop, lot size 25 => ₹500 risk per lot; ₹250 cannot fund one lot.
    assert quantity_for_risk(100, 25, 250, .20) == 0

def test_approve_rejects_insufficient_risk():
    d = approve_entry(RiskState(), 100, 25)
    assert not d.allowed

def test_kill_switch_blocks():
    d = approve_entry(RiskState(kill_switch=True), 10, 1)
    assert not d.allowed
    assert "Kill switch" in d.reason

def test_daily_loss_blocks():
    d = approve_entry(RiskState(realized_pnl=-1000), 10, 1)
    assert not d.allowed

def test_trade_limit_blocks():
    d = approve_entry(RiskState(trades_today=5), 10, 1)
    assert not d.allowed
