package com.example.niftyalgostarter

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var halted = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }

        val title = TextView(this).apply {
            text = "NIFTY Algo Starter"
            textSize = 26f
            setTextColor(Color.rgb(20, 28, 40))
        }
        val mode = TextView(this).apply {
            text = "PAPER MODE ONLY • No live orders"
            textSize = 15f
            setTextColor(Color.rgb(0, 110, 75))
            setPadding(0, 12, 0, 24)
        }
        status = TextView(this).apply {
            text = "Strategy: EMA 12/26 + RSI 14\nCE: RSI > 55\nPE: RSI < 45\nTimeframe: 5 minutes\nRisk/trade: ₹250\nDaily loss limit: ₹1,000\nMax trades/day: 5\nPremium stop: 20%"
            textSize = 17f
            setTextColor(Color.rgb(30, 35, 45))
            setPadding(0, 8, 0, 28)
        }
        val stop = Button(this).apply {
            text = "EMERGENCY STOP (LOCAL DEMO)"
            setOnClickListener {
                halted = true
                status.text = "KILL SWITCH LATCHED\nNew entries must remain blocked.\nConnect this control to an authenticated backend endpoint before real use."
                Toast.makeText(this@MainActivity, "Demo kill switch latched locally", Toast.LENGTH_LONG).show()
            }
        }
        val note = TextView(this).apply {
            text = "Prototype UI only. The button is local-only and does not contact a server. No broker is connected."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(mode)
        root.addView(status)
        root.addView(stop)
        root.addView(note)
        setContentView(root)
    }
}
